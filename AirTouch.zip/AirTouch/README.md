# Air Touch

Control your Android phone with your hand, using the camera. A circle follows your chosen
fingertip over every app; pinch (or push toward the camera) to tap, keep still to hold,
raise two fingers (index + middle) and move your hand to scroll.

## Build the APK without a computer
1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab -> **Build APK** -> **Run workflow**.
3. When it finishes, download the **AirTouch-debug-apk** artifact, unzip, install `app-debug.apk`.

## Or with Android Studio
Open this folder, let Gradle sync, press Run.

## First run
1. Open Air Touch, allow Camera (and notifications).
2. Accessibility -> Air Touch -> turn on. (Android 13+ sideloaded apps: App info -> ⋮ -> Allow restricted settings first.)
3. Flip **Hand control** on. The first start downloads the ~8 MB hand model (needs internet once).

## Structure
- `HandControlService` camera + MediaPipe hand landmarks + gesture engine (foreground service)
- `GestureService` accessibility service: draws the cursor overlay and performs taps/holds/swipes
- `MainActivity` toggle, setup status and all settings

## Speed notes (v1.1)
- One Euro smoothing: steady when slow, no delay when fast. The circle is redrawn on every screen refresh.
- Live touch: the touch lands the moment you pinch and lifts when you release; hold then move drags;
  a quick pinch + move cancels. Scrolling is a real finger that follows your hand and flings when you stop.
  Turn it off in the app for the classic tap-on-release behaviour.
- GPU tracking with automatic CPU fallback. The notification shows tracking fps.

## v1.2
- Clicks come only from a freshly formed pinch: never while scrolling, never right after a scroll ends,
  and a hand that returns already pinched does not click. A thumb touching the index finger can no longer
  start scroll mode.
- Scroll touches are guaranteed to travel past the tap distance before and when they lift, so a scroll
  can never be read as a tap.
- The circle follows your hand with a critically damped spring (continuous speed, no per-update jerks).
  The Smoothing slider sets both the tracking filter and the spring stiffness. Scrolling uses a steadier filter.

## v1.3 - accuracy
- Finger poses are judged from 3D joint angles (the model's metric 3D landmarks), so index + middle up
  with ring + little folded is recognised from any angle: hand tilted, sideways, palm toward or away
  from the camera, fingers pointing at the camera. The circle turns purple as soon as it is held for 2 frames.
- Pinch = 2D and 3D distance together, so fingertips that merely overlap from the front don't click.
- Ghost rejection: hand must stay ~3 frames before the circle appears; one-frame teleports are ignored;
  hands too far / too close / leaving the view are ignored; the circle only follows a pointing finger
  (fades when the pointer finger is curled). Detection strictness is adjustable.
- The notification shows tracking fps and hints (too dark / too bright / hand too far ...).

# Air Touch

Control your Android phone with your hand, using the camera. A circle follows your chosen
fingertip over every app; pinch (or push toward the camera) to tap, keep still to hold,
move while pinched to swipe/scroll.

## Build the APK without a computer
1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab -> **Build APK** -> **Run workflow**.
3. When it finishes, download the **AirTouch-debug-apk** artifact, unzip, install `app-debug.apk`.

## Or with Android Studio
Open this folder, let Gradle sync, press Run.

## First run
1. Open Air Touch, allow Camera (and notifications).
2. Accessibility -> Air Touch -> turn on. (Android 13+ sideloaded apps: App info -> ⋮ -> Allow restricted settings first.)
3. Flip **Hand control** on. The first start downloads the ~8 MB hand model (needs internet once).

## Structure
- `HandControlService` camera + MediaPipe hand landmarks + gesture engine (foreground service)
- `GestureService` accessibility service: draws the cursor overlay and performs taps/holds/swipes
- `MainActivity` toggle, setup status and all settings

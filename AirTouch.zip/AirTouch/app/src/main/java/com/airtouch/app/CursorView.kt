package com.airtouch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.Choreographer
import android.view.View
import kotlin.math.abs
import kotlin.math.exp

/**
 * Full-screen, touch-transparent view that draws the floating circle.
 *
 * The hand tracker delivers a new position ~30 times a second. To avoid visible stepping, the
 * circle is redrawn on every screen refresh and glides the last few milliseconds toward the
 * newest position. It never moves ahead of the hand - it only ever shows where the finger is.
 */
class CursorView(ctx: Context) : View(ctx) {

    companion object {
        const val JUMP_NONE = 0     // normal sample
        const val JUMP_SNAP = 2     // cursor (re)appeared: appear right there
    }

    private class Target(val x: Float, val y: Float, val mode: Int)

    @Volatile var radiusPx = 40f
    @Volatile var omega = 80f        // spring stiffness (rad/s): higher = tighter, lower = silkier
    @Volatile var state = 0          // 0 hovering, 1 touching, 2 holding, 3 scrolling (purple), 4 not pointing (faded)
    @Volatile var shown = false
    @Volatile private var tgt = Target(0.5f, 0.5f, JUMP_SNAP)

    // main thread only
    private var cx = 0.5f
    private var cy = 0.5f
    private var cvx = 0f             // spring velocity (screen fractions per second)
    private var cvy = 0f
    private var lastSnap: Target? = null
    private var looping = false
    private var lastFrameNs = 0L
    private var drawnX = -1f
    private var drawnY = -1f
    private var drawnState = -1
    private var drawnR = -1f

    private val kick = Runnable { startLoop() }
    private val frameCb = Choreographer.FrameCallback { ns -> step(ns) }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.WHITE
    }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 10f; color = Color.argb(110, 0, 0, 0)
    }

    /** Called from the tracking thread with the newest hand position (0..1 of the screen). */
    fun setTarget(nx: Float, ny: Float, st: Int, r: Float, visible: Boolean, jump: Int, w: Float) {
        val mode = if (!shown) JUMP_SNAP else jump
        omega = w
        state = st
        radiusPx = r
        tgt = Target(nx, ny, mode)
        shown = visible
        post(kick)
    }

    private fun startLoop() {
        if (looping || !shown) return
        looping = true
        lastFrameNs = 0L
        drawnState = -1                       // force a redraw when the circle (re)appears
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    private fun step(frameNs: Long) {
        if (!shown) { looping = false; return }
        val t = tgt
        val dt = if (lastFrameNs == 0L) 0.016f else ((frameNs - lastFrameNs) / 1e9f).coerceIn(0.001f, 0.1f)
        lastFrameNs = frameNs

        if (t.mode == JUMP_SNAP && t !== lastSnap) { cx = t.x; cy = t.y; cvx = 0f; cvy = 0f; lastSnap = t }

        // Critically damped spring (exact solution, stable at any frame rate). Unlike a plain
        // "move a fraction toward the target", its speed changes smoothly, so the ~30 position
        // updates per second blend into one continuous glide instead of a series of small jerks.
        val w = omega
        val e = exp(-w * dt)
        val x0 = cx - t.x
        val ax = cvx + w * x0
        cx = t.x + (x0 + ax * dt) * e
        cvx = (cvx - ax * w * dt) * e
        val y0 = cy - t.y
        val ay = cvy + w * y0
        cy = t.y + (y0 + ay * dt) * e
        cvy = (cvy - ay * w * dt) * e

        if (abs(cx - drawnX) * width > 0.05f || abs(cy - drawnY) * height > 0.05f ||
            state != drawnState || radiusPx != drawnR
        ) {
            drawnX = cx; drawnY = cy; drawnState = state; drawnR = radiusPx
            invalidate()
        }
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(frameCb)
        looping = false
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        if (!shown) return
        val x = cx * width
        val y = cy * height
        val r: Float
        when (state) {
            1 -> { r = radiusPx * 0.65f; fill.color = Color.argb(180, 46, 204, 113) }
            2 -> { r = radiusPx * 0.80f; fill.color = Color.argb(180, 255, 152, 0) }
            3 -> { r = radiusPx * 0.80f; fill.color = Color.argb(180, 171, 71, 255) }
            4 -> { r = radiusPx * 0.90f; fill.color = Color.argb(40, 48, 176, 255) }   // faded: not pointing
            else -> { r = radiusPx; fill.color = Color.argb(90, 48, 176, 255) }
        }
        val dim = state == 4
        ring.alpha = if (dim) 110 else 255
        shadow.alpha = if (dim) 40 else 110
        c.drawCircle(x, y, r, fill)
        c.drawCircle(x, y, r, shadow)
        c.drawCircle(x, y, r, ring)
        c.drawCircle(x, y, 4f, ring)
    }
}

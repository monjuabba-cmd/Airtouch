package com.airtouch.app

import android.content.Context

/** All user settings. The tracking service reads these on every frame, so changes apply live. */
class Prefs(ctx: Context) {
    val sp = ctx.getSharedPreferences("airtouch", Context.MODE_PRIVATE)

    var finger: Int                       // 0 thumb, 1 index, 2 middle, 3 ring, 4 little
        get() = sp.getInt("finger", 1)
        set(v) { sp.edit().putInt("finger", v).apply() }
    var mode: Int                         // 0 = pinch, 1 = push toward camera
        get() = sp.getInt("mode", 0)
        set(v) { sp.edit().putInt("mode", v).apply() }
    var gain: Float                       // how far the cursor travels per hand movement
        get() = sp.getFloat("gain", 1.8f)
        set(v) { sp.edit().putFloat("gain", v).apply() }
    var smoothing: Int                    // 0..90 %
        get() = sp.getInt("smoothing", 50)
        set(v) { sp.edit().putInt("smoothing", v).apply() }
    var sens: Int                         // 0..100, higher = easier to click
        get() = sp.getInt("sens", 50)
        set(v) { sp.edit().putInt("sens", v).apply() }
    var holdMs: Int
        get() = sp.getInt("holdMs", 600)
        set(v) { sp.edit().putInt("holdMs", v).apply() }
    var cursorDp: Int
        get() = sp.getInt("cursorDp", 44)
        set(v) { sp.edit().putInt("cursorDp", v).apply() }
    var front: Boolean
        get() = sp.getBoolean("front", true)
        set(v) { sp.edit().putBoolean("front", v).apply() }
    var showCursor: Boolean
        get() = sp.getBoolean("showCursor", true)
        set(v) { sp.edit().putBoolean("showCursor", v).apply() }

    companion object {
        val FINGERS = arrayOf("Thumb", "Index finger", "Middle finger", "Ring finger", "Little finger")
        /** MediaPipe hand landmark ids of each fingertip. */
        val TIPS = intArrayOf(4, 8, 12, 16, 20)
    }
}

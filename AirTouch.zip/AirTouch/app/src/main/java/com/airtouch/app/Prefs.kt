package com.airtouch.app

import android.content.Context

/** All user settings. The tracking service reads these on every frame, so changes apply live. */
class Prefs(ctx: Context) {
    val sp = ctx.getSharedPreferences("airtouch", Context.MODE_PRIVATE)

    var finger: Int                       // 0 thumb, 1 index, 2 middle, 3 ring, 4 little
        get() = sp.getInt("finger", 1)
        set(v) { sp.edit().putInt("finger", v).apply() }
    var mode: Int                         // 0 = pinch, 1 = push toward camera
        get() = sp.getInt("mode", 0)
        set(v) { sp.edit().putInt("mode", v).apply() }
    var gain: Float                       // how far the cursor travels per hand movement
        get() = sp.getFloat("gain", 1.8f)
        set(v) { sp.edit().putFloat("gain", v).apply() }
    var smoothing: Int                    // 0..90 %, higher = steadier when slow (fast moves stay instant)
        get() = sp.getInt("smooth2", 40)
        set(v) { sp.edit().putInt("smooth2", v).apply() }
    var sens: Int                         // 0..100, higher = easier to click
        get() = sp.getInt("sens", 50)
        set(v) { sp.edit().putInt("sens", v).apply() }
    var holdMs: Int
        get() = sp.getInt("holdMs", 600)
        set(v) { sp.edit().putInt("holdMs", v).apply() }
    var scrollSpeed: Int                  // percent; how far the page moves per hand movement
        get() = sp.getInt("scrollSpeed", 100)
        set(v) { sp.edit().putInt("scrollSpeed", v).apply() }
    var cursorDp: Int
        get() = sp.getInt("cursorDp", 44)
        set(v) { sp.edit().putInt("cursorDp", v).apply() }
    var front: Boolean
        get() = sp.getBoolean("front", true)
        set(v) { sp.edit().putBoolean("front", v).apply() }
    var live: Boolean                     // touch goes down the moment you pinch, lifts when you release
        get() = sp.getBoolean("live", true)
        set(v) { sp.edit().putBoolean("live", v).apply() }
    var gpu: Boolean                      // run hand tracking on the GPU
        get() = sp.getBoolean("gpu", true)
        set(v) { sp.edit().putBoolean("gpu", v).apply() }
    var pointOnly: Boolean                // the circle only moves while the pointer finger is out
        get() = sp.getBoolean("pointOnly", true)
        set(v) { sp.edit().putBoolean("pointOnly", v).apply() }
    var conf: Int                         // detection strictness 40..85 (%)
        get() = sp.getInt("conf", 60)
        set(v) { sp.edit().putInt("conf", v).apply() }
    var shake: Int                        // ignore hand tremor smaller than this many dp (0 = off)
        get() = sp.getInt("shake", 6)
        set(v) { sp.edit().putInt("shake", v).apply() }
    var voice: Boolean                    // voice scroll: say left / right / up / down
        get() = sp.getBoolean("voice", false)
        set(v) { sp.edit().putBoolean("voice", v).apply() }
    var voiceInvert: Boolean
        get() = sp.getBoolean("voiceInvert", false)
        set(v) { sp.edit().putBoolean("voiceInvert", v).apply() }
    var showCursor: Boolean
        get() = sp.getBoolean("showCursor", true)
        set(v) { sp.edit().putBoolean("showCursor", v).apply() }

    companion object {
        val FINGERS = arrayOf("Thumb", "Index finger", "Middle finger", "Ring finger", "Little finger")
        /** MediaPipe hand landmark ids of each fingertip. */
        val TIPS = intArrayOf(4, 8, 12, 16, 20)
    }
}

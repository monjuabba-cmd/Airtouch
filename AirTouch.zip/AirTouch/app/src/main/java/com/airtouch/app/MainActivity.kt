package com.airtouch.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private val bg = Color.parseColor("#0F1115")
    private val cardBg = Color.parseColor("#1A1D24")
    private val sub = Color.parseColor("#9AA3B2")
    private val good = Color.parseColor("#3DDC84")
    private val bad = Color.parseColor("#FF6B6B")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        window.statusBarColor = bg
    }

    override fun onResume() {
        super.onResume()
        HandControlService.onState = { runOnUiThread { render() } }
        render()
    }

    override fun onPause() {
        HandControlService.onState = null
        super.onPause()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        render()
    }

    // ---- screen -----------------------------------------------------------------------------

    private fun render() {
        val camOk = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val a11yOk = GestureService.isEnabled(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(30), dp(18), dp(40))
        }
        col.addView(label("Air Touch", 30f, bold = true))
        col.addView(label("Control your phone with your hand - no touching.", 14f, sub))

        val master = Switch(this).apply {
            text = "Hand control"
            textSize = 20f
            setTextColor(Color.WHITE)
            isChecked = HandControlService.running
            setPadding(0, dp(6), 0, dp(6))
        }
        master.setOnCheckedChangeListener { _, on ->
            if (on) {
                if (!turnOn()) master.post { render() }
            } else {
                stopService(Intent(this, HandControlService::class.java))
            }
        }
        col.addView(section(master))

        col.addView(section(
            label("Setup", 16f, bold = true),
            statusRow("Camera access", camOk, "Allow") { askPermissions() },
            statusRow("Accessibility service", a11yOk, "Enable") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            label(
                "Accessibility: find Air Touch under Installed/Downloaded apps and turn it on. " +
                    "If it's greyed out (Android 13+): Settings > Apps > Air Touch > ⋮ > Allow restricted settings.",
                12f, sub
            )
        ))

        col.addView(section(
            label("Tracking", 16f, bold = true),
            spinnerRow("Finger used as pointer", Prefs.FINGERS, prefs.finger) { prefs.finger = it },
            spinnerRow(
                "Click gesture",
                arrayOf("Pinch (fingertip touches thumb)", "Push (move hand toward camera)"),
                prefs.mode
            ) { prefs.mode = it },
            seekRow("Cursor speed", 10, 30, (prefs.gain * 10).roundToInt(), { "%.1fx".format(it / 10f) }) {
                prefs.gain = it / 10f
            },
            seekRow("Smoothing", 0, 90, prefs.smoothing, { "$it%" }) { prefs.smoothing = it },
            seekRow("Click sensitivity (higher = easier)", 0, 100, prefs.sens, { "$it" }) { prefs.sens = it },
            seekRow("Hold time (cursor turns orange)", 300, 1500, prefs.holdMs, { "$it ms" }) { prefs.holdMs = it },
            seekRow("Scroll speed", 30, 300, prefs.scrollSpeed, { "$it%" }) { prefs.scrollSpeed = it }
        ))

        col.addView(section(
            label("Accuracy", 16f, bold = true),
            switchRow("Move the circle only while my finger is out", prefs.pointOnly) { prefs.pointOnly = it },
            seekRow("Detection strictness (higher = fewer ghost hands)", 40, 85, prefs.conf, { "$it%" }) { prefs.conf = it },
            label(
                "Index + middle finger up with ring and little folded turns the circle purple and scrolls - from any angle. " +
                    "If the circle stops following you, lower the strictness or turn the first switch off.",
                12f, sub
            )
        ))

        col.addView(section(
            label("Speed", 16f, bold = true),
            switchRow("Live touch (touch lands the instant you pinch)", prefs.live) { prefs.live = it },
            switchRow("GPU tracking (faster; auto-falls back to CPU)", prefs.gpu) { prefs.gpu = it },
            label(
                "The notification shows your tracking speed. Bright light keeps the camera at full frame rate. " +
                    "If touches ever misbehave, switch Live touch off to get the classic taps.",
                12f, sub
            )
        ))

        col.addView(section(
            label("Cursor & camera", 16f, bold = true),
            seekRow("Cursor size", 20, 80, prefs.cursorDp, { "$it dp" }) { prefs.cursorDp = it },
            switchRow("Show cursor circle", prefs.showCursor) { prefs.showCursor = it },
            switchRow("Use front camera", prefs.front) { prefs.front = it }
        ))

        col.addView(section(
            label("How to use", 16f, bold = true),
            label(
                "Tap: do the click gesture and release.\n" +
                    "Hold: do the click gesture and keep still.\n" +
                    "Scroll: raise two fingers (index + middle) and fold the others, then move your hand up / down / sideways - no pinching. The circle turns purple.\n\n" +
                    "Keep your hand about an arm's length from the camera, in good light.",
                13f, sub
            )
        ))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bg)
            addView(col)
        })
    }

    private fun turnOn(): Boolean {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            toast("Allow camera access first")
            return false
        }
        if (!GestureService.isEnabled(this)) {
            toast("Enable the Air Touch accessibility service first")
            return false
        }
        ContextCompat.startForegroundService(this, Intent(this, HandControlService::class.java))
        return true
    }

    private fun askPermissions() {
        val p = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }

    // ---- tiny UI helpers --------------------------------------------------------------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun label(t: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun section(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply { setColor(cardBg); cornerRadius = dp(16).toFloat() }
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) }
        views.forEach { addView(it) }
    }

    private fun statusRow(name: String, ok: Boolean, action: String, onClick: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
            addView(
                label((if (ok) "✓  " else "✗  ") + name, 15f, if (ok) good else bad),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
            if (!ok) addView(Button(this@MainActivity).apply {
                text = action
                setOnClickListener { onClick() }
            })
        }

    private fun spinnerRow(title: String, items: Array<String>, selected: Int, onPick: (Int) -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, 0)
            addView(label(title, 14f))
            addView(Spinner(this@MainActivity).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
                setSelection(selected)
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onPick(pos) }
                    override fun onNothingSelected(p: AdapterView<*>?) {}
                }
            })
        }

    private fun seekRow(
        title: String, minV: Int, maxV: Int, value: Int,
        fmt: (Int) -> String, onChange: (Int) -> Unit
    ): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, dp(10), 0, 0)
        val tv = label("$title: ${fmt(value)}", 14f)
        addView(tv)
        addView(SeekBar(this@MainActivity).apply {
            max = maxV - minV
            progress = value - minV
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + minV
                    tv.text = "$title: ${fmt(v)}"
                    if (fromUser) onChange(v)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun switchRow(title: String, on: Boolean, onChange: (Boolean) -> Unit): View =
        Switch(this).apply {
            text = title
            setTextColor(Color.WHITE)
            isChecked = on
            setPadding(0, dp(12), 0, dp(4))
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
}

package com.airtouch.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/**
 * Two jobs, both of which work on top of every other app:
 *  1. draws the cursor circle (accessibility overlay - no extra permission needed)
 *  2. performs taps / long-presses / swipes on the real screen
 */
class GestureService : AccessibilityService() {

    companion object {
        @Volatile var instance: GestureService? = null

        fun isEnabled(ctx: Context): Boolean {
            val enabled = Settings.Secure.getString(
                ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val cn = ComponentName(ctx, GestureService::class.java)
            return enabled.split(':').any {
                it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
            }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var cursor: CursorView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        addOverlay()
    }

    private fun addOverlay() {
        if (cursor != null) return
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = CursorView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        manager.addView(view, lp)
        wm = manager
        cursor = view
    }

    private fun removeOverlay() {
        cursor?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        cursor = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        removeOverlay()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        removeOverlay()
        super.onDestroy()
    }

    // ---- cursor -----------------------------------------------------------------------------

    fun screenW(): Int = cursor?.width ?: 0
    fun screenH(): Int = cursor?.height ?: 0

    fun moveCursor(
        nx: Float, ny: Float, state: Int, radiusPx: Float, visible: Boolean,
        jump: Int = CursorView.JUMP_NONE
    ) {
        val c = cursor ?: return
        c.setTarget(nx, ny, state, radiusPx, visible, jump)
    }

    fun hideCursor() {
        val c = cursor ?: return
        c.shown = false
        c.postInvalidate()
    }

    // ---- gestures (coordinates are 0..1 of the screen) --------------------------------------

    private fun ready() = screenW() > 10 && screenH() > 10
    private fun px(n: Float) = (n * screenW()).coerceIn(2f, screenW() - 2f)
    private fun py(n: Float) = (n * screenH()).coerceIn(2f, screenH() - 2f)

    fun tap(nx: Float, ny: Float) {
        if (!ready()) return
        send(Path().apply { moveTo(px(nx), py(ny)) }, 50)
    }

    fun longPress(nx: Float, ny: Float) {
        if (!ready()) return
        send(Path().apply { moveTo(px(nx), py(ny)) }, 700)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        if (!ready()) return
        send(Path().apply { moveTo(px(x1), py(y1)); lineTo(px(x2), py(y2)) }, durationMs)
    }

    @Volatile private var scrollBusyUntil = 0L

    /** True while a scroll swipe is still running (a new gesture would cancel it). */
    fun scrollBusy(): Boolean = SystemClock.uptimeMillis() < scrollBusyUntil

    /**
     * One scroll swipe centred on the cursor (ax, ay = 0..1 of the screen), dxPx/dyPx pixels long.
     * It follows the hand like a real finger: hand down -> finger drags down.
     * Kept away from the screen edges so it never triggers Back / Home gestures.
     */
    fun scrollSwipe(ax: Float, ay: Float, dxPx: Float, dyPx: Float, durationMs: Long) {
        if (!ready()) return
        val d = resources.displayMetrics.density
        val w = screenW().toFloat()
        val h = screenH().toFloat()
        val xLo = 32f * d
        val xHi = (w - 32f * d).coerceAtLeast(xLo)
        val yLo = 48f * d
        val yHi = (h - 72f * d).coerceAtLeast(yLo)
        val cx = (ax * w).coerceIn(xLo, xHi)
        val cy = (ay * h).coerceIn(yLo, yHi)
        val x1 = (cx - dxPx / 2f).coerceIn(xLo, xHi)
        val x2 = (cx + dxPx / 2f).coerceIn(xLo, xHi)
        val y1 = (cy - dyPx / 2f).coerceIn(yLo, yHi)
        val y2 = (cy + dyPx / 2f).coerceIn(yLo, yHi)
        if (abs(x2 - x1) + abs(y2 - y1) < 8f * d) return     // too short: would turn into a tap
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        scrollBusyUntil = SystemClock.uptimeMillis() + durationMs + 400
        try {
            dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) { scrollBusyUntil = 0L }
                override fun onCancelled(gestureDescription: GestureDescription?) { scrollBusyUntil = 0L }
            }, main)
        } catch (_: Exception) {
            scrollBusyUntil = 0L
        }
    }

    private fun send(path: Path, durationMs: Long) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        // dispatch right away from the tracking thread (no hop through the UI thread)
        try {
            dispatchGesture(g, null, null)
        } catch (_: Exception) {
            main.post { try { dispatchGesture(g, null, null) } catch (_: Exception) {} }
        }
    }
}

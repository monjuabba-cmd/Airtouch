package com.airtouch.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.view.Display
import android.view.Surface
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.hypot
import kotlin.math.sqrt

private const val TAG = "AirTouch"
private const val MODEL_FILE = "hand_landmarker.task"
private const val BETA = 6f                 // One Euro: how fast the filter opens up when the hand moves quickly
private const val VOICE_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
private const val VOICE_DIR = "vosk-model-small-en-us-0.15"
private data class P(val t: Long, val x: Float, val y: Float)

/**
 * Ignores hand tremor: the output only moves once the input has left a small circle around it,
 * and then it is dragged along just far enough to keep the input at the circle's edge.
 */
private class DeadZone {
    var x = 0f
    var y = 0f
    private var has = false

    fun reset() { has = false }

    fun update(tx: Float, ty: Float, sw: Float, sh: Float, radiusPx: Float) {
        if (!has || radiusPx <= 0.5f || sw < 10f || sh < 10f) { x = tx; y = ty; has = true; return }
        val dx = (tx - x) * sw
        val dy = (ty - y) * sh
        val d = hypot(dx, dy)
        if (d > radiusPx) {
            val k = 1f - radiusPx / d
            x += (tx - x) * k
            y += (ty - y) * k
        }
    }
}

/**
 * One Euro filter: steady when the hand is slow (no jitter), almost no delay when it moves fast.
 * That is what a plain "average with the last position" smoothing could never do.
 */
private class OneEuro {
    private var has = false
    private var xPrev = 0f
    private var dxPrev = 0f
    private var tPrev = 0L

    fun reset() { has = false }

    fun filter(x: Float, tMs: Long, minCutoff: Float, beta: Float): Float {
        if (!has) { has = true; xPrev = x; dxPrev = 0f; tPrev = tMs; return x }
        val dt = (tMs - tPrev).coerceAtLeast(1L) / 1000f
        tPrev = tMs
        val dx = (x - xPrev) / dt
        val aD = alpha(dt, 1.0f)
        val dxHat = aD * dx + (1f - aD) * dxPrev
        val cutoff = minCutoff + beta * abs(dxHat)
        val a = alpha(dt, cutoff)
        val xHat = a * x + (1f - a) * xPrev
        xPrev = xHat
        dxPrev = dxHat
        return xHat
    }

    private fun alpha(dt: Float, cutoff: Float): Float {
        val tau = 1f / (2f * Math.PI.toFloat() * cutoff)
        return 1f / (1f + tau / dt)
    }
}

/**
 * Foreground service: camera -> MediaPipe hand landmarks -> cursor + touches.
 * Because it is a foreground service it keeps running while you use other apps.
 */
class HandControlService : LifecycleService() {

    companion object {
        const val ACTION_STOP = "com.airtouch.app.STOP"
        const val ACTION_VOICE_OFF = "com.airtouch.app.VOICE_OFF"
        private const val CHANNEL = "airtouch"
        private const val MODEL_URL =
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"

        @Volatile var running = false
        @Volatile var voiceOn = false               // true while voice is really listening (the screen shows it)
        @Volatile var onState: (() -> Unit)? = null
    }

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var landmarker: HandLandmarker? = null
    @Volatile private var usingGpu = false
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    private val resultCount = AtomicInteger(0)

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "front") main.post { bindCamera() }
        if (key == "gpu" && prefs.gpu != usingGpu) rebuildLandmarker()
        if (key == "voice") main.post { syncVoice() }
        if (key == "conf") { main.removeCallbacks(rebuildRun); main.postDelayed(rebuildRun, 700) }
    }
    private val rebuildRun = Runnable { rebuildLandmarker() }
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { analysis?.targetRotation = rotation() }
    }

    // gesture state (touched only from the MediaPipe result thread)
    private var sx = 0.5f
    private var sy = 0.5f
    private var haveFix = false
    private var lostFrames = 0
    private val hist = ArrayDeque<P>()
    private var pressed = false
    private var moved = false
    private var holdFired = false
    private var dragging = false
    private var liveTouch = false       // was this press started as a live touch?
    private var touchOpen = false       // is the live touch currently down on the screen?
    private var downT = 0L
    private var startX = 0f
    private var startY = 0f
    private var anchorX = 0f
    private var anchorY = 0f
    private var baseline = 0f
    private var jump = CursorView.JUMP_NONE

    // smoothing filters
    private val filtX = OneEuro()
    private val filtY = OneEuro()
    private val filtHX = OneEuro()
    private val filtHY = OneEuro()

    // two-finger scroll mode (no pinching needed)
    private var scrollMode = false
    private var scrollLive = false
    private var scrollOpen = false      // live scroll: touch is down
    private var fingerPxX = 0f
    private var fingerPxY = 0f
    private var lastMoveT = 0L
    private var poseFrames = 0
    private var noPoseFrames = 0
    private var shx = 0f
    private var shy = 0f
    private var accX = 0f
    private var accY = 0f
    private var scrollDownX = 0f        // where the live scroll finger went down (px)
    private var scrollDownY = 0f
    private var downPrev = true         // previous frame's raw pinch state: a click needs a FRESH pinch
    private var lastScrollEndT = 0L

    // hand-validity / ghost rejection
    private val wxyz = FloatArray(63)               // 21 hand points in 3D (x, y, z each)
    private val fs = FloatArray(5)                  // straightness of thumb..little finger, 0..1
    private var pointing = true
    private var rawX = 0f
    private var rawY = 0f
    private var lastTs = 0L
    private var candX = 0f
    private var candY = 0f
    private var candN = 0
    private var stableRun = 0
    private var badFrames = 0
    @Volatile private var hint = ""
    @Volatile private var light = -1                // average picture brightness 0..255 (sampled)
    private var lightTick = 0
    private val dzC = DeadZone()                    // steadies the circle
    private val dzS = DeadZone()                    // steadies scrolling

    // voice scroll
    private var speech: SpeechService? = null
    private var voiceModel: Model? = null
    private var voiceRec: Recognizer? = null
    @Volatile private var voiceLoading = false
    @Volatile private var voiceGen = 0
    @Volatile private var voiceActive = false
    private var vDone = 0
    private var vLast: List<String> = emptyList()
    private val voiceQ = ArrayDeque<FloatArray>()

    // tracking speed stats (shown in the notification)
    private var statFrames = 0
    private var statLat = 0L
    private var statT0 = 0L

    // camera frame buffers, reused every frame (allocating ~2.5 MB per frame made the GC stall tracking)
    private var rawBmp: Bitmap? = null
    private var upBmp: Bitmap? = null
    private var upCanvas: Canvas? = null
    private val rotM = Matrix()
    private val copyPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }

    // ---- lifecycle --------------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, main)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_VOICE_OFF) { prefs.voice = false; return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        running = true

        ServiceCompat.startForeground(
            this, 1, buildNotification("Starting…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        )

        Thread {
            val model = ensureModel()
            if (model == null) {
                main.post {
                    Toast.makeText(this, "Couldn't download the hand model - check your internet and try again.", Toast.LENGTH_LONG).show()
                    stopSelf()
                }
                return@Thread
            }
            // the tracker is created on the same thread that later feeds it frames (needed for the GPU)
            try {
                exec.execute {
                    try {
                        landmarker = buildLandmarker(model)
                    } catch (e: Exception) {
                        Log.e(TAG, "landmarker init failed", e)
                        main.post {
                            Toast.makeText(this, "Hand tracker failed to start: ${e.message}", Toast.LENGTH_LONG).show()
                            stopSelf()
                        }
                        return@execute
                    }
                    main.post { bindCamera() }
                }
            } catch (_: Exception) {}
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacks(voicePump)
        stopVoice()
        GestureService.instance?.let { abortTouches(it) }
        prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        try { provider?.unbindAll() } catch (_: Exception) {}
        analysis?.clearAnalyzer()
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        exec.shutdown()
        GestureService.instance?.hideCursor()
        onState?.let { cb -> main.post { cb() } }
        super.onDestroy()
    }

    // ---- setup helpers ----------------------------------------------------------------------

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Air Touch", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(
            this, 0, Intent(this, HandControlService::class.java).setAction(ACTION_STOP), flags
        )
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), flags)
        val nb = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Air Touch is on")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Turn off", stop
                ).build()
            )
        if (voiceLoading || speech != null) {
            val voiceOff = PendingIntent.getService(
                this, 2, Intent(this, HandControlService::class.java).setAction(ACTION_VOICE_OFF), flags
            )
            nb.addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "Stop voice", voiceOff
                ).build()
            )
        }
        return nb.build()
    }

    private fun setStatus(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
    }

    /** The ~8 MB hand model is downloaded once, on first use. */
    private fun ensureModel(): File? {
        val f = File(filesDir, MODEL_FILE)
        if (f.exists() && f.length() > 1_000_000) return f
        return try {
            val tmp = File(filesDir, "model.tmp")
            val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            conn.disconnect()
            if (tmp.renameTo(f)) f else null
        } catch (e: Exception) {
            Log.e(TAG, "model download failed", e)
            null
        }
    }

    /** GPU first (about twice as fast on most phones); falls back to the CPU if the GPU can't do it. */
    private fun buildLandmarker(model: File): HandLandmarker {
        val bytes = model.readBytes()
        val conf = (prefs.conf / 100f).coerceIn(0.3f, 0.9f)

        fun make(gpu: Boolean): HandLandmarker {
            val buf = ByteBuffer.allocateDirect(bytes.size)
            buf.put(bytes)
            buf.rewind()
            val base = BaseOptions.builder()
                .setModelAssetBuffer(buf)
                .setDelegate(if (gpu) Delegate.GPU else Delegate.CPU)
                .build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(conf)
                .setMinHandPresenceConfidence(conf)
                .setMinTrackingConfidence(conf * 0.85f)
                .setResultListener { result, input -> onResult(result, input) }
                .setErrorListener { e -> Log.e(TAG, "mediapipe error", e) }
                .build()
            return HandLandmarker.createFromOptions(this, options)
        }

        if (prefs.gpu) {
            try {
                val l = make(true)
                usingGpu = true
                return l
            } catch (t: Throwable) {
                Log.w(TAG, "GPU delegate failed, using CPU", t)
                usingGpu = false
                prefs.gpu = false
            }
        }
        usingGpu = false
        return make(false)
    }

    /** Switch GPU/CPU while running (the tracker is swapped on the analysis thread, between frames). */
    private fun rebuildLandmarker() {
        val model = File(filesDir, MODEL_FILE)
        if (!model.exists()) return
        try {
            exec.execute {
                try { landmarker?.close() } catch (_: Exception) {}
                landmarker = null
                try {
                    landmarker = buildLandmarker(model)
                } catch (e: Exception) {
                    Log.e(TAG, "rebuild failed", e)
                }
            }
        } catch (_: Exception) {}
    }

    private fun rotation(): Int {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        return dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val ia = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder().setResolutionStrategy(
                            ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                        ).build()
                    )
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setTargetRotation(rotation())
                    .build()
                ia.setAnalyzer(exec) { analyze(it) }
                analysis = ia
                p.unbindAll()
                p.bindToLifecycle(
                    this,
                    if (prefs.front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                    ia
                )
                haveFix = false
                setStatus("Hand tracking active")
                syncVoice()

                // safety net: if the GPU tracker never produces a single result, drop back to the CPU
                resultCount.set(0)
                main.postDelayed({
                    if (running && usingGpu && resultCount.get() == 0) {
                        Toast.makeText(this, "GPU tracking isn't supported on this phone - switched to CPU", Toast.LENGTH_LONG).show()
                        prefs.gpu = false
                    }
                }, 6000)
            } catch (e: Exception) {
                Log.e(TAG, "camera bind failed", e)
                Toast.makeText(this, "Camera failed to start: ${e.message}", Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val lm = landmarker
        try {
            if (lm != null) {
                val w = proxy.width
                val h = proxy.height
                var raw = rawBmp
                if (raw == null || raw.width != w || raw.height != h) {
                    raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    rawBmp = raw
                }
                val buf = proxy.planes[0].buffer
                buf.rewind()
                raw.copyPixelsFromBuffer(buf)

                if (++lightTick % 20 == 0) {            // every ~0.7 s: how bright is the picture?
                    var sum = 0L
                    var n = 0
                    var yy = 8
                    while (yy < h) {
                        var xx = 8
                        while (xx < w) {
                            val c = raw.getPixel(xx, yy)
                            sum += ((c shr 16) and 0xFF) * 3 + ((c shr 8) and 0xFF) * 6 + (c and 0xFF)
                            n++
                            xx += 40
                        }
                        yy += 40
                    }
                    if (n > 0) light = (sum / (n * 10L)).toInt()
                }

                // rotate upright into a reused bitmap (same result as before, without the garbage)
                val deg = proxy.imageInfo.rotationDegrees
                val swap = deg == 90 || deg == 270
                val uw = if (swap) h else w
                val uh = if (swap) w else h
                var up = upBmp
                var canvas = upCanvas
                if (up == null || canvas == null || up.width != uw || up.height != uh) {
                    up = Bitmap.createBitmap(uw, uh, Bitmap.Config.ARGB_8888)
                    canvas = Canvas(up)
                    upBmp = up
                    upCanvas = canvas
                }
                rotM.reset()
                rotM.postRotate(deg.toFloat())
                when (deg) {
                    90 -> rotM.postTranslate(h.toFloat(), 0f)
                    180 -> rotM.postTranslate(w.toFloat(), h.toFloat())
                    270 -> rotM.postTranslate(0f, w.toFloat())
                }
                canvas.drawBitmap(raw, rotM, copyPaint)
                lm.detectAsync(BitmapImageBuilder(up).build(), SystemClock.uptimeMillis())
            }
        } catch (e: Exception) {
            Log.e(TAG, "analyze failed", e)
        } finally {
            proxy.close()
        }
    }

    private fun trackStats(res: HandLandmarkerResult, now: Long) {
        resultCount.incrementAndGet()
        statFrames++
        statLat += (now - res.timestampMs()).coerceAtLeast(0L)
        if (statT0 == 0L) statT0 = now
        if (now - statT0 >= 3000L) {
            val fps = statFrames * 1000f / (now - statT0)
            val lat = statLat / statFrames
            val extra = StringBuilder()
            if (light in 0..60) extra.append(" | too dark")
            if (light > 235) extra.append(" | too bright")
            if (hint.isNotEmpty()) extra.append(" | ").append(hint)
            setStatus("Tracking %.0f fps, %d ms%s%s".format(fps, lat, if (usingGpu) " (GPU)" else " (CPU)", extra))
            statFrames = 0; statLat = 0L; statT0 = now
        }
    }

    // ---- voice scroll: say "left", "right", "up" or "down" -----------------------------------
    // Offline recognizer limited to those four words (Vosk), so there are no beeps, no internet
    // after the one-time model download, and everything else that is said is ignored.

    private fun syncVoice() {
        val want = prefs.voice &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (want && speech == null && !voiceLoading) startVoice()
        if (!want && (speech != null || voiceLoading)) stopVoice()
    }

    /** Tells the app screen whether voice is listening (it shows "Listening now" / "Voice is off"). */
    private fun setVoiceOn(on: Boolean) {
        if (voiceOn == on) return
        voiceOn = on
        onState?.let { cb -> main.post { cb() } }
    }

    private fun startVoice() {
        val gen = ++voiceGen                    // every start/stop gets a new number, so a stale start can never survive a stop
        voiceLoading = true
        try {
            // the microphone has to be part of the foreground type before it is opened
            ServiceCompat.startForeground(
                this, 1, buildNotification("Starting voice…"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } catch (e: Exception) {
            Log.e(TAG, "voice: can't use the microphone now", e)
            voiceLoading = false
            Toast.makeText(this, "Voice couldn't start - open Air Touch and switch it on again", Toast.LENGTH_LONG).show()
            prefs.voice = false
            return
        }
        Thread {
            val dir = ensureVoiceModel(gen)
            if (dir == null) {
                main.post {
                    if (gen == voiceGen) {      // not cancelled: it really failed
                        voiceLoading = false
                        Toast.makeText(this, "Couldn't download the voice model - check your internet and try again.", Toast.LENGTH_LONG).show()
                        prefs.voice = false
                    }
                }
                return@Thread
            }
            try {
                val model = Model(dir.absolutePath)
                val rec = Recognizer(model, 16000.0f, "[\"left\", \"right\", \"up\", \"down\", \"[unk]\"]")
                val sp = SpeechService(rec, 16000.0f)
                main.post {
                    if (gen != voiceGen || !running || !prefs.voice) {
                        closeVoiceAsync(sp, rec, model)         // it was switched off while loading
                    } else {
                        voiceModel = model
                        voiceRec = rec
                        speech = sp
                        voiceLoading = false
                        voiceActive = true
                        sp.startListening(voiceListener)
                        setVoiceOn(true)
                        setStatus("Listening: say left, right, up or down")
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "voice init failed", e)
                main.post {
                    if (gen == voiceGen) {
                        voiceLoading = false
                        Toast.makeText(this, "Voice failed to start: ${e.message}", Toast.LENGTH_LONG).show()
                        prefs.voice = false
                    }
                }
            }
        }.start()
    }

    /** Turns voice completely off: stops listening, releases the microphone, cancels any download. */
    private fun stopVoice() {
        voiceGen++                              // cancels a download / start that is still in progress
        voiceActive = false                     // anything the recognizer still says is ignored from now on
        val sp = speech
        val rec = voiceRec
        val mod = voiceModel
        speech = null
        voiceRec = null
        voiceModel = null
        voiceLoading = false
        voiceQ.clear()
        vDone = 0
        vLast = emptyList()
        closeVoiceAsync(sp, rec, mod)
        setVoiceOn(false)
        if (running) {                          // back to a camera-only service (drops the microphone indicator)
            try {
                ServiceCompat.startForeground(
                    this, 1, buildNotification("Hand tracking active"), ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                )
            } catch (_: Exception) {}
        }
    }

    /** Releases the microphone and the voice engine on a worker thread, each step on its own so none can block the others. */
    private fun closeVoiceAsync(sp: SpeechService?, rec: Recognizer?, model: Model?) {
        Thread {
            try { sp?.stop() } catch (_: Throwable) {}
            try { sp?.shutdown() } catch (_: Throwable) {}
            try { rec?.close() } catch (_: Throwable) {}
            try { model?.close() } catch (_: Throwable) {}
        }.start()
    }

    /** The small offline English voice model (~40 MB), downloaded once. Stops early if voice is switched off. */
    private fun ensureVoiceModel(gen: Int): File? {
        val dir = File(filesDir, VOICE_DIR)
        if (File(dir, "am/final.mdl").exists()) return dir
        return try {
            main.post { if (gen == voiceGen) setStatus("Downloading the voice model (about 40 MB)…") }
            val zip = File(filesDir, "voice.zip")
            val conn = URL(VOICE_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.inputStream.use { input ->
                zip.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        if (gen != voiceGen) throw IllegalStateException("cancelled")
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                }
            }
            conn.disconnect()
            val root = filesDir.canonicalPath
            ZipInputStream(zip.inputStream().buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    if (gen != voiceGen) throw IllegalStateException("cancelled")
                    val out = File(filesDir, e.name)
                    if (!out.canonicalPath.startsWith(root)) throw SecurityException("bad zip entry")
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o -> zin.copyTo(o) }
                    }
                    e = zin.nextEntry
                }
            }
            zip.delete()
            if (File(dir, "am/final.mdl").exists()) dir else null
        } catch (e: Exception) {
            Log.e(TAG, "voice model download stopped", e)
            null
        }
    }

    private val voiceListener = object : RecognitionListener {
        override fun onPartialResult(hypothesis: String?) { voiceText(jsonField(hypothesis, "partial"), false) }
        override fun onResult(hypothesis: String?) { voiceText(jsonField(hypothesis, "text"), true) }
        override fun onFinalResult(hypothesis: String?) { voiceText(jsonField(hypothesis, "text"), true) }
        override fun onError(exception: Exception?) { Log.e(TAG, "voice error", exception) }
        override fun onTimeout() {}
    }

    private fun jsonField(json: String?, key: String): String =
        try { JSONObject(json ?: "{}").optString(key, "") } catch (_: Exception) { "" }

    /** Runs on the recognizer's thread. A word counts once it shows up in two partial results in a row (or in the final one). */
    private fun voiceText(text: String, final: Boolean) {
        if (!voiceActive) return                            // voice was switched off: ignore anything still arriving
        val tokens = text.lowercase().split(' ').filter { it.isNotEmpty() }
        if (tokens.size < vDone) vDone = 0                  // the guess was revised: start over
        var i = vDone
        while (i < tokens.size) {
            val confirmed = final || vLast.getOrNull(i) == tokens[i]
            if (!confirmed) break
            voiceCommand(tokens[i])
            i++
        }
        vDone = i
        if (final) { vDone = 0; vLast = emptyList() } else vLast = tokens
    }

    private fun voiceCommand(word: String) {
        var dx = 0f                                         // finger movement: "down" = finger up = page moves down
        var dy = 0f
        when (word) {
            "down" -> dy = -1f
            "up" -> dy = 1f
            "left" -> dx = 1f
            "right" -> dx = -1f
            else -> return
        }
        if (prefs.voiceInvert) { dx = -dx; dy = -dy }
        main.post {
            if (voiceActive && voiceQ.size < 4) voiceQ.addLast(floatArrayOf(dx, dy))
            voicePump.run()
        }
    }

    /** Sends the queued voice scrolls one after another ("down down" scrolls twice). */
    private val voicePump = object : Runnable {
        private var waitSince = 0L

        override fun run() {
            val svc = GestureService.instance
            if (svc == null || !voiceActive) { voiceQ.clear(); waitSince = 0L; return }
            if (voiceQ.isEmpty()) return
            val now = SystemClock.uptimeMillis()
            if (svc.scrollBusy() || pressed || scrollOpen || touchOpen) {   // wait until nothing else is touching
                if (waitSince == 0L) waitSince = now
                if (now - waitSince > 3000L) { voiceQ.clear(); waitSince = 0L; return }   // give up, never loop forever
                main.removeCallbacks(this)
                main.postDelayed(this, 120)
                return
            }
            waitSince = 0L
            val v = voiceQ.removeFirst()
            val sw = svc.screenW().toFloat()
            val sh = svc.screenH().toFloat()
            val cx = if (haveFix) sx else 0.5f
            svc.scrollSwipe(cx, 0.5f, v[0] * 0.5f * sw, v[1] * 0.45f * sh, 200L)
            if (voiceQ.isNotEmpty()) {
                main.removeCallbacks(this)
                main.postDelayed(this, 300)
            }
        }
    }

    // ---- 3D hand geometry (works from any viewing angle) -------------------------------------

    /** Distance between two of the 21 hand points, in 3D. */
    private fun d3(a: Int, b: Int): Float {
        val dx = wxyz[3 * a] - wxyz[3 * b]
        val dy = wxyz[3 * a + 1] - wxyz[3 * b + 1]
        val dz = wxyz[3 * a + 2] - wxyz[3 * b + 2]
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    /** Angle in degrees at joint b between the bones b->a and b->c (180 = perfectly straight). */
    private fun ang3(a: Int, b: Int, c: Int): Float {
        val ax = wxyz[3 * a] - wxyz[3 * b]
        val ay = wxyz[3 * a + 1] - wxyz[3 * b + 1]
        val az = wxyz[3 * a + 2] - wxyz[3 * b + 2]
        val cx = wxyz[3 * c] - wxyz[3 * b]
        val cy = wxyz[3 * c + 1] - wxyz[3 * b + 1]
        val cz = wxyz[3 * c + 2] - wxyz[3 * b + 2]
        val na = sqrt(ax * ax + ay * ay + az * az).coerceAtLeast(1e-6f)
        val nc = sqrt(cx * cx + cy * cy + cz * cz).coerceAtLeast(1e-6f)
        val cosA = ((ax * cx + ay * cy + az * cz) / (na * nc)).coerceIn(-1f, 1f)
        return Math.toDegrees(acos(cosA).toDouble()).toFloat()
    }

    /**
     * How straight a finger is: 0 = fully curled, 1 = fully straight (f: 0 thumb, 1 index ... 4 little).
     * It looks at the bend of the two finger joints in 3D, so it doesn't matter whether the hand is
     * upright, sideways, tilted or pointing at the camera.
     */
    private fun straight(f: Int): Float {
        if (f == 0) {
            val a1 = ang3(1, 2, 3)
            val a2 = ang3(2, 3, 4)
            return 0.5f * ((a1 - 120f) / 50f).coerceIn(0f, 1f) + 0.5f * ((a2 - 120f) / 50f).coerceIn(0f, 1f)
        }
        val a = 4 * f + 1                       // knuckle; then +1 middle joint, +2 top joint, +3 tip
        val a1 = ang3(a, a + 1, a + 2)
        val a2 = ang3(a + 1, a + 2, a + 3)
        return 0.65f * ((a1 - 100f) / 70f).coerceIn(0f, 1f) + 0.35f * ((a2 - 110f) / 60f).coerceIn(0f, 1f)
    }

    // ---- gesture engine ---------------------------------------------------------------------

    private fun onResult(res: HandLandmarkerResult, img: MPImage) {
        val now = SystemClock.uptimeMillis()
        trackStats(res, now)
        val svc = GestureService.instance ?: return
        val hands = res.landmarks()
        if (hands.isEmpty()) { handLost(svc); return }

        val lm = hands[0]
        val w = img.width.toFloat()
        val h = img.height.toFloat()
        fun dist(a: Int, b: Int) = hypot((lm[a].x() - lm[b].x()) * w, (lm[a].y() - lm[b].y()) * h)

        val tip = Prefs.TIPS[prefs.finger.coerceIn(0, 4)]
        val palm = dist(0, 9).coerceAtLeast(1f)           // wrist -> middle knuckle = hand size

        // 0) is this a real, fully visible hand? Ghost detections and half-visible hands are ignored.
        var problem: String? = null
        val rel = palm / minOf(w, h)
        if (rel < 0.05f) problem = "hand too far"
        else if (rel > 0.8f) problem = "hand too close"
        if (problem == null) {
            var outside = 0
            for (p in lm) if (p.x() < 0f || p.x() > 1f || p.y() < 0f || p.y() > 1f) outside++
            if (outside >= 3) problem = "hand leaving the view"
        }
        if (problem == null) {
            val t = lm[tip]
            val m = 0.012f
            if (t.x() < m || t.x() > 1f - m || t.y() < m || t.y() > 1f - m) problem = "fingertip at the edge"
        }
        if (problem != null) {
            hint = problem
            if (!haveFix) stableRun = 0
            badFrames++
            if (badFrames >= 3) handLost(svc)               // 1-2 bad frames: just hold still
            return
        }
        badFrames = 0
        hint = ""
        lostFrames = 0

        val ts = res.timestampMs()
        val density = resources.displayMetrics.density

        // 3D joint positions: the model's own metric 3D estimate when it provides one
        val worlds = res.worldLandmarks()
        val haveWorld = worlds.isNotEmpty() && worlds[0].size >= 21
        if (haveWorld) {
            val wl = worlds[0]
            for (i in 0 until 21) {
                wxyz[3 * i] = wl[i].x(); wxyz[3 * i + 1] = wl[i].y(); wxyz[3 * i + 2] = wl[i].z()
            }
        } else {
            for (i in 0 until 21) {
                wxyz[3 * i] = lm[i].x() * w; wxyz[3 * i + 1] = lm[i].y() * h; wxyz[3 * i + 2] = lm[i].z() * w
            }
        }
        for (f in 0..4) {                                   // how straight is each finger (lightly smoothed)
            val s = straight(f)
            fs[f] = if (!haveFix) s else fs[f] * 0.5f + s * 0.5f
        }

        // 1) where is the chosen fingertip, in screen terms (mirrored for the selfie camera)
        var nx = lm[tip].x()
        if (prefs.front) nx = 1f - nx
        var ny = lm[tip].y()
        val g = prefs.gain
        nx = ((nx - 0.5f) * g + 0.5f).coerceIn(0f, 1f)
        ny = ((ny - 0.5f) * g + 0.5f).coerceIn(0f, 1f)

        // a position that suddenly leaps across the screen is a ghost detection: wait for it to repeat
        var teleported = false
        if (haveFix) {
            val dtS = (ts - lastTs).coerceAtLeast(1L) / 1000f
            if (hypot(nx - rawX, ny - rawY) > 0.25f + 2.5f * dtS) {
                if (hypot(nx - candX, ny - candY) < 0.10f) candN++ else { candX = nx; candY = ny; candN = 1 }
                if (candN < 3) return
                teleported = true
            }
            candN = 0
        }
        rawX = nx; rawY = ny; lastTs = ts

        if (teleported) { filtX.reset(); filtY.reset(); jump = CursorView.JUMP_SNAP }
        val minCutoff = 0.3f + 3.7f * (1f - prefs.smoothing / 100f)
        val ffx = filtX.filter(nx, ts, minCutoff, BETA)
        val ffy = filtY.filter(ny, ts, minCutoff, BETA)
        val swPx = svc.screenW().toFloat()
        val shPx = svc.screenH().toFloat()
        val shakePx = prefs.shake * density                 // "ignore small shaking" radius
        if (teleported || !haveFix) { dzC.reset(); dzS.reset() }
        dzC.update(ffx, ffy, swPx, shPx, shakePx)
        val fx = dzC.x
        val fy = dzC.y
        if (teleported) { sx = fx; sy = fy }
        if (!haveFix) {
            stableRun++
            if (stableRun < 3) return                       // a hand must stay ~3 frames before the circle appears
            sx = fx; sy = fy; haveFix = true; jump = CursorView.JUMP_SNAP; stableRun = 0
        }

        // is the pointer finger out? (the circle only follows a pointing finger)
        val ps = fs[prefs.finger.coerceIn(0, 4)]
        pointing = if (pointing) ps > 0.35f else ps > 0.55f
        val follow = pointing || !prefs.pointOnly

        // 1b) scroll pose: index + middle finger straight, ring + little curled - judged in 3D joint angles
        val palm3 = d3(0, 9).coerceAtLeast(1e-4f)
        val thumbToIndex = d3(4, 8) / palm3
        val sIdx = fs[1]; val sMid = fs[2]; val sRing = fs[3]; val sLit = fs[4]
        val poseNow = if (scrollMode) {
            sIdx > 0.5f && sMid > 0.5f && sRing < 0.7f && sLit < 0.7f      // once scrolling, be forgiving
        } else {
            sIdx > 0.72f && sMid > 0.72f && sRing < 0.5f && sLit < 0.5f
        }
        val pose = poseNow && thumbToIndex > 0.45f           // thumb pinching the index finger = a click, never a scroll
        if (pose) { poseFrames++; noPoseFrames = 0 } else { noPoseFrames++; poseFrames = 0 }
        var hx = (lm[8].x() + lm[12].x()) / 2f            // the two raised fingertips, mid-point
        if (prefs.front) hx = 1f - hx
        var hy = (lm[8].y() + lm[12].y()) / 2f
        hx = (hx - 0.5f) * g + 0.5f
        hy = (hy - 0.5f) * g + 0.5f
        val scrollCutoff = (minCutoff * 0.6f).coerceAtLeast(0.2f)
        val ffhx = filtHX.filter(hx, ts, scrollCutoff, BETA)
        val ffhy = filtHY.filter(hy, ts, scrollCutoff, BETA)
        dzS.update(ffhx, ffhy, swPx, shPx, shakePx * 0.6f)
        val fhx = dzS.x
        val fhy = dzS.y
        if (!scrollMode && poseFrames >= 2) {
            scrollMode = true
            cancelPinch(svc)                                      // a pinch in progress is cancelled, not clicked
            scrollLive = prefs.live
            scrollOpen = false
            shx = fhx; shy = fhy; accX = 0f; accY = 0f
        } else if (scrollMode && noPoseFrames >= 4) {
            scrollMode = false
            endScroll(svc)
            lastScrollEndT = now
            sx = fx; sy = fy                                      // cursor is right at the fingertip again
            jump = CursorView.JUMP_SNAP
        }

        // 2) is the "touch" gesture active?
        val sens = prefs.sens / 100f
        val down: Boolean
        if (scrollMode) {
            down = false                          // pinching does nothing while scrolling
        } else if (prefs.mode == 0) {
            // pinch: fingertip meets thumb tip (thumb pointer pinches with the index finger).
            // Measured in 2D and in 3D together, so overlapping fingertips seen from the front
            // (but far apart in depth) don't count as a pinch.
            val partner = if (prefs.finger == 0) 8 else 4
            val ratio2 = dist(tip, partner) / palm
            val ratio3 = d3(tip, partner) / palm3
            val ratio = if (haveWorld) 0.4f * ratio2 + 0.6f * ratio3 else ratio2
            val on = 0.10f + 0.40f * sens
            down = if (pressed) ratio < on * 1.4f else ratio < on
        } else {
            // push: hand moves toward the camera, so it looks bigger than its recent average
            if (baseline == 0f) baseline = palm
            val ratio = palm / baseline
            val on = 1f + (0.35f - 0.30f * sens)
            val off = 1f + (on - 1f) * 0.5f
            down = if (pressed) ratio > off else ratio > on
            if (!pressed && !down) baseline += (palm - baseline) * 0.03f
        }

        // 3) press / release transitions
        // a click only starts from a freshly formed pinch, and never while scrolling (or just after)
        val clickBlocked = scrollMode || poseFrames > 0 || now - lastScrollEndT < 400L
        val fresh = down && !downPrev
        downPrev = down
        if (down && !pressed && fresh && !clickBlocked) {
            pressed = true; moved = false; holdFired = false; dragging = false; downT = now
            // the fingertip drifts while pinching/pushing, so use where it was ~0.2 s ago
            val p = hist.firstOrNull { now - it.t <= 200 } ?: P(now, sx, sy)
            startX = p.x; startY = p.y
            anchorX = fx; anchorY = fy
            sx = startX; sy = startY
            liveTouch = prefs.live
            if (liveTouch) {                       // the touch lands right now, not when you let go
                svc.touchDown(startX, startY)
                touchOpen = true
            }
        } else if (!down && pressed) {
            release(svc, now)
        }

        // 4) cursor; while touching it moves relative to the touch-down point;
        //    when the pointer finger isn't out, the circle stays where it was
        if (!scrollMode) {
            if (pressed) {
                sx = (startX + (fx - anchorX)).coerceIn(0f, 1f)
                sy = (startY + (fy - anchorY)).coerceIn(0f, 1f)
            } else if (follow) {
                sx = fx; sy = fy
            }
        } else if (scrollLive) {
            scrollLiveStep(svc, fhx, fhy, now, density)
        } else {
            scrollStep(svc, fhx, fhy, 1f, density)    // cursor stays put, the hand scrolls the page under it
        }

        // 5) moved too far early -> the pinch is cancelled (no click); stayed still -> hold; hold then move -> drag
        if (pressed) {
            val far = hypot((sx - startX) * svc.screenW(), (sy - startY) * svc.screenH()) > 36f * density
            if (!holdFired) {
                if (!moved && far) {
                    moved = true
                    if (liveTouch && touchOpen) cancelLift(svc)
                }
                if (!moved && now - downT >= prefs.holdMs) {
                    holdFired = true
                    if (!liveTouch) svc.longPress(startX, startY)
                }
            } else if (liveTouch && touchOpen && (dragging || far)) {
                dragging = true
                svc.touchMove(sx, sy)
            }
        }

        hist.addLast(P(now, sx, sy))
        while (hist.isNotEmpty() && now - hist.first().t > 300) hist.removeFirst()

        // purple (3) = two-finger scroll gesture, faded (4) = pointer finger not out
        val state = if (scrollMode) 3 else if (pressed) (if (holdFired) 2 else 1) else if (!follow) 4 else 0
        val omega = 100f - 0.6f * prefs.smoothing            // 100 (tight) .. 46 (silky)
        svc.moveCursor(sx, sy, state, prefs.cursorDp * density / 2f, prefs.showCursor, jump, omega)
        jump = CursorView.JUMP_NONE
    }

    /** Live scroll: a real finger goes down under the cursor and follows your hand 1:1; lifting it flings. */
    private fun scrollLiveStep(svc: GestureService, hx: Float, hy: Float, now: Long, density: Float) {
        val sw = svc.screenW().toFloat()
        val sh = svc.screenH().toFloat()
        if (sw < 10f || sh < 10f) return
        val speed = prefs.scrollSpeed / 100f
        val mx = (hx - shx) * sw * speed
        val my = (hy - shy) * sh * speed
        shx = hx
        shy = hy
        val dead = 1.5f * density
        val still = abs(mx) < dead && abs(my) < dead
        // keep the finger away from the screen edges so it never triggers Back / Home gestures
        val xLo = 32f * density
        val xHi = (sw - 32f * density).coerceAtLeast(xLo)
        val yLo = 48f * density
        val yHi = (sh - 72f * density).coerceAtLeast(yLo)

        if (!scrollOpen) {
            if (still) { accX *= 0.9f; accY *= 0.9f } else { accX += mx; accY += my }
            if (hypot(accX, accY) >= 14f * density) {
                // start in the middle band of the screen so there is room to move both ways
                val bandLo = maxOf(yLo, 0.3f * sh)
                val bandHi = maxOf(bandLo, minOf(yHi, 0.7f * sh))
                val y0 = (sy * sh).coerceIn(bandLo, bandHi)
                fingerPxX = (sx * sw).coerceIn(xLo, xHi)
                fingerPxY = y0
                scrollDownX = fingerPxX
                scrollDownY = fingerPxY
                svc.touchDown(fingerPxX / sw, fingerPxY / sh)
                scrollOpen = true
                lastMoveT = now
                fingerPxX = (fingerPxX + accX).coerceIn(xLo, xHi)
                fingerPxY = (fingerPxY + accY).coerceIn(yLo, yHi)
                accX = 0f; accY = 0f
                svc.touchMove(fingerPxX / sw, fingerPxY / sh)
            }
        } else {
            fingerPxX = (fingerPxX + mx).coerceIn(xLo, xHi)
            fingerPxY = (fingerPxY + my).coerceIn(yLo, yHi)
            if (!still) lastMoveT = now
            svc.touchMove(fingerPxX / sw, fingerPxY / sh)
            if (now - lastMoveT > 300L) {          // hand paused: lift so the page isn't "long-pressed"
                liftScroll(svc, sw, sh, density)
                scrollOpen = false
                accX = 0f; accY = 0f
            }
        }
    }

    /** Classic scroll (Live touch off): the cursor stays put and the hand scrolls the page under it. */
    private fun scrollStep(svc: GestureService, hx: Float, hy: Float, a: Float, density: Float) {
        val sw = svc.screenW().toFloat()
        val sh = svc.screenH().toFloat()
        if (sw < 10f || sh < 10f) return
        val px0 = shx
        val py0 = shy
        shx += (hx - shx) * a
        shy += (hy - shy) * a
        val speed = prefs.scrollSpeed / 100f
        var mx = (shx - px0) * sw * speed
        var my = (shy - py0) * sh * speed
        val dead = 1.5f * density
        if (abs(mx) < dead) { mx = 0f; accX *= 0.9f }       // ignore tiny jitter
        if (abs(my) < dead) { my = 0f; accY *= 0.9f }
        accX += mx
        accY += my
        if (svc.scrollBusy()) return                        // let the previous swipe finish first
        val step = 36f * density
        val ax = abs(accX)
        val ay = abs(accY)
        if (ay >= step && ay >= ax) {
            val d = accY.coerceIn(-0.45f * sh, 0.45f * sh)
            svc.scrollSwipe(sx, sy, 0f, d, (60f + abs(d) / 4f).toLong().coerceIn(80L, 220L))
            accX = 0f; accY = 0f
        } else if (ax >= step) {
            val d = accX.coerceIn(-0.45f * sw, 0.45f * sw)
            svc.scrollSwipe(sx, sy, d, 0f, (60f + abs(d) / 4f).toLong().coerceIn(80L, 220L))
            accX = 0f; accY = 0f
        }
    }

    private fun release(svc: GestureService, now: Long) {
        pressed = false
        if (liveTouch) {
            if (touchOpen) {
                touchOpen = false
                if (dragging) svc.touchUp(sx, sy) else svc.touchUp(startX, startY)
            }
        } else if (!holdFired && !moved) {
            svc.tap(startX, startY)                         // classic: pinch = tap on release
        }
        moved = false
        holdFired = false
        dragging = false
    }

    /** End an open live touch without it counting as a click (drag it a little past the tap slop first). */
    private fun cancelLift(svc: GestureService) {
        if (!touchOpen) return
        touchOpen = false
        if (dragging) { svc.touchUp(sx, sy); return }
        val w = svc.screenW().toFloat().coerceAtLeast(1f)
        val h = svc.screenH().toFloat().coerceAtLeast(1f)
        val dxp = (sx - startX) * w
        val dyp = (sy - startY) * h
        val len = hypot(dxp, dyp)
        val ux = if (len > 1f) dxp / len else 0f
        val uy = if (len > 1f) dyp / len else 1f
        val off = 18f * resources.displayMetrics.density
        svc.touchUp(startX + ux * off / w, startY + uy * off / h)
    }

    private fun cancelPinch(svc: GestureService) {
        if (liveTouch && touchOpen) cancelLift(svc)
        pressed = false; moved = false; holdFired = false; dragging = false
    }

    private fun endScroll(svc: GestureService) {
        if (scrollOpen) {
            scrollOpen = false
            val sw = svc.screenW().toFloat().coerceAtLeast(1f)
            val sh = svc.screenH().toFloat().coerceAtLeast(1f)
            liftScroll(svc, sw, sh, resources.displayMetrics.density)
        }
        accX = 0f; accY = 0f
    }

    /** Lift the scroll finger at least 22 dp from where it went down, so a scroll can never be read as a tap. */
    private fun liftScroll(svc: GestureService, sw: Float, sh: Float, density: Float) {
        var ux = fingerPxX
        var uy = fingerPxY
        val dx = ux - scrollDownX
        val dy = uy - scrollDownY
        val len = hypot(dx, dy)
        val need = 22f * density
        if (len < need) {
            val dirX = if (len > 1f) dx / len else 0f
            val dirY = if (len > 1f) dy / len else 1f
            ux = (scrollDownX + dirX * need).coerceIn(2f, sw - 2f)
            uy = (scrollDownY + dirY * need).coerceIn(2f, sh - 2f)
        }
        svc.touchUp(ux / sw, uy / sh)
    }

    private fun abortTouches(svc: GestureService) {
        cancelPinch(svc)
        endScroll(svc)
    }

    private fun handLost(svc: GestureService) {
        lostFrames++
        if (!haveFix) stableRun = 0
        if (lostFrames > 6) {
            if (pressed) cancelPinch(svc)         // hand left the frame mid-touch: cancel, don't click
            if (scrollMode) { endScroll(svc); lastScrollEndT = SystemClock.uptimeMillis() }
            scrollMode = false; poseFrames = 0; noPoseFrames = 0
        }
        if (lostFrames > 12 && haveFix) {
            haveFix = false
            stableRun = 0
            candN = 0
            pointing = true
            downPrev = true                       // a hand that comes back already pinched must not click
            hist.clear()
            baseline = 0f
            filtX.reset(); filtY.reset(); filtHX.reset(); filtHY.reset()
            dzC.reset(); dzS.reset()
            svc.hideCursor()
        }
    }
}

package com.airtouch.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.view.Display
import android.view.Surface
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import kotlin.math.hypot

private const val TAG = "AirTouch"
private data class P(val t: Long, val x: Float, val y: Float)

/**
 * Foreground service: camera -> MediaPipe hand landmarks -> cursor + tap/hold/swipe.
 * Because it is a foreground service it keeps running while you use other apps.
 */
class HandControlService : LifecycleService() {

    companion object {
        const val ACTION_STOP = "com.airtouch.app.STOP"
        private const val CHANNEL = "airtouch"
        private const val MODEL_URL =
            "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"

        @Volatile var running = false
        @Volatile var onState: (() -> Unit)? = null
    }

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "front") main.post { bindCamera() }
    }
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) { analysis?.targetRotation = rotation() }
    }

    // gesture state (touched only from the MediaPipe result thread)
    private var sx = 0.5f
    private var sy = 0.5f
    private var haveFix = false
    private var lostFrames = 0
    private val hist = ArrayDeque<P>()
    private var pressed = false
    private var moved = false
    private var holdFired = false
    private var downT = 0L
    private var startX = 0f
    private var startY = 0f
    private var anchorX = 0f
    private var anchorY = 0f
    private var baseline = 0f
    private var jump = CursorView.JUMP_NONE

    // camera frame buffers, reused every frame (allocating ~2.5 MB per frame made the GC stall tracking)
    private var rawBmp: Bitmap? = null
    private var upBmp: Bitmap? = null
    private var upCanvas: Canvas? = null
    private val rotM = Matrix()
    private val copyPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }

    // ---- lifecycle --------------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, main)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        running = true

        ServiceCompat.startForeground(
            this, 1, buildNotification("Starting…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        )

        Thread {
            val model = ensureModel()
            if (model == null) {
                main.post {
                    Toast.makeText(this, "Couldn't download the hand model - check your internet and try again.", Toast.LENGTH_LONG).show()
                    stopSelf()
                }
                return@Thread
            }
            try {
                landmarker = createLandmarker(model)
            } catch (e: Exception) {
                Log.e(TAG, "landmarker init failed", e)
                main.post {
                    Toast.makeText(this, "Hand tracker failed to start: ${e.message}", Toast.LENGTH_LONG).show()
                    stopSelf()
                }
                return@Thread
            }
            main.post { bindCamera() }
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        try { provider?.unbindAll() } catch (_: Exception) {}
        analysis?.clearAnalyzer()
        try { landmarker?.close() } catch (_: Exception) {}
        landmarker = null
        exec.shutdown()
        GestureService.instance?.hideCursor()
        onState?.let { cb -> main.post { cb() } }
        super.onDestroy()
    }

    // ---- setup helpers ----------------------------------------------------------------------

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Air Touch", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stop = PendingIntent.getService(
            this, 0, Intent(this, HandControlService::class.java).setAction(ACTION_STOP), flags
        )
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), flags)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Air Touch is on")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Turn off", stop
                ).build()
            )
            .build()
    }

    private fun setStatus(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
    }

    /** The ~8 MB hand model is downloaded once, on first use. */
    private fun ensureModel(): File? {
        val f = File(filesDir, "hand_landmarker.task")
        if (f.exists() && f.length() > 1_000_000) return f
        return try {
            val tmp = File(filesDir, "model.tmp")
            val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            conn.disconnect()
            if (tmp.renameTo(f)) f else null
        } catch (e: Exception) {
            Log.e(TAG, "model download failed", e)
            null
        }
    }

    private fun createLandmarker(model: File): HandLandmarker {
        val bytes = model.readBytes()
        val buf = ByteBuffer.allocateDirect(bytes.size)
        buf.put(bytes)
        buf.rewind()
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(buf).build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, input -> onResult(result, input) }
            .setErrorListener { e -> Log.e(TAG, "mediapipe error", e) }
            .build()
        return HandLandmarker.createFromOptions(this, options)
    }

    private fun rotation(): Int {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        return dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
    }

    private fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val ia = ImageAnalysis.Builder()
                    .setResolutionSelector(
                        ResolutionSelector.Builder().setResolutionStrategy(
                            ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                        ).build()
                    )
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .setTargetRotation(rotation())
                    .build()
                ia.setAnalyzer(exec) { analyze(it) }
                analysis = ia
                p.unbindAll()
                p.bindToLifecycle(
                    this,
                    if (prefs.front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                    ia
                )
                haveFix = false
                setStatus("Hand tracking active")
            } catch (e: Exception) {
                Log.e(TAG, "camera bind failed", e)
                Toast.makeText(this, "Camera failed to start: ${e.message}", Toast.LENGTH_LONG).show()
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val lm = landmarker
        try {
            if (lm != null) {
                val w = proxy.width
                val h = proxy.height
                var raw = rawBmp
                if (raw == null || raw.width != w || raw.height != h) {
                    raw = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    rawBmp = raw
                }
                val buf = proxy.planes[0].buffer
                buf.rewind()
                raw.copyPixelsFromBuffer(buf)

                // rotate upright into a reused bitmap (same result as before, without the garbage)
                val deg = proxy.imageInfo.rotationDegrees
                val swap = deg == 90 || deg == 270
                val uw = if (swap) h else w
                val uh = if (swap) w else h
                var up = upBmp
                var canvas = upCanvas
                if (up == null || canvas == null || up.width != uw || up.height != uh) {
                    up = Bitmap.createBitmap(uw, uh, Bitmap.Config.ARGB_8888)
                    canvas = Canvas(up)
                    upBmp = up
                    upCanvas = canvas
                }
                rotM.reset()
                rotM.postRotate(deg.toFloat())
                when (deg) {
                    90 -> rotM.postTranslate(h.toFloat(), 0f)
                    180 -> rotM.postTranslate(w.toFloat(), h.toFloat())
                    270 -> rotM.postTranslate(0f, w.toFloat())
                }
                canvas.drawBitmap(raw, rotM, copyPaint)
                lm.detectAsync(BitmapImageBuilder(up).build(), SystemClock.uptimeMillis())
            }
        } catch (e: Exception) {
            Log.e(TAG, "analyze failed", e)
        } finally {
            proxy.close()
        }
    }

    // ---- gesture engine ---------------------------------------------------------------------

    private fun onResult(res: HandLandmarkerResult, img: MPImage) {
        val svc = GestureService.instance ?: return
        val hands = res.landmarks()
        if (hands.isEmpty()) { handLost(svc); return }
        lostFrames = 0

        val lm = hands[0]
        val w = img.width.toFloat()
        val h = img.height.toFloat()
        fun dist(a: Int, b: Int) = hypot((lm[a].x() - lm[b].x()) * w, (lm[a].y() - lm[b].y()) * h)

        val tip = Prefs.TIPS[prefs.finger.coerceIn(0, 4)]
        val palm = dist(0, 9).coerceAtLeast(1f)           // wrist -> middle knuckle = hand size
        val now = SystemClock.uptimeMillis()
        val density = resources.displayMetrics.density

        // 1) where is the chosen fingertip, in screen terms (mirrored for the selfie camera)
        var nx = lm[tip].x()
        if (prefs.front) nx = 1f - nx
        var ny = lm[tip].y()
        val g = prefs.gain
        nx = ((nx - 0.5f) * g + 0.5f).coerceIn(0f, 1f)
        ny = ((ny - 0.5f) * g + 0.5f).coerceIn(0f, 1f)
        if (!haveFix) { sx = nx; sy = ny; haveFix = true; jump = CursorView.JUMP_SNAP }

        // 2) is the "touch" gesture active?
        val sens = prefs.sens / 100f
        val down: Boolean
        if (prefs.mode == 0) {
            // pinch: fingertip meets thumb tip (thumb pointer pinches with the index finger)
            val partner = if (prefs.finger == 0) 8 else 4
            val ratio = dist(tip, partner) / palm
            val on = 0.10f + 0.40f * sens
            down = if (pressed) ratio < on * 1.5f else ratio < on
        } else {
            // push: hand moves toward the camera, so it looks bigger than its recent average
            if (baseline == 0f) baseline = palm
            val ratio = palm / baseline
            val on = 1f + (0.35f - 0.30f * sens)
            val off = 1f + (on - 1f) * 0.5f
            down = if (pressed) ratio > off else ratio > on
            if (!pressed && !down) baseline += (palm - baseline) * 0.03f
        }

        // 3) press / release transitions
        if (down && !pressed) {
            pressed = true; moved = false; holdFired = false; downT = now
            // the fingertip drifts while pinching/pushing, so use where it was ~0.2 s ago
            val p = hist.firstOrNull { now - it.t <= 200 } ?: P(now, sx, sy)
            startX = p.x; startY = p.y
            anchorX = nx; anchorY = ny
            sx = startX; sy = startY
        } else if (!down && pressed) {
            release(svc, now)
        }

        // 4) smooth cursor; while touching it moves relative to the touch-down point
        val tx = if (pressed) (startX + (nx - anchorX)).coerceIn(0f, 1f) else nx
        val ty = if (pressed) (startY + (ny - anchorY)).coerceIn(0f, 1f) else ny
        val a = (1f - prefs.smoothing / 100f).coerceIn(0.1f, 1f)
        sx += (tx - sx) * a
        sy += (ty - sy) * a

        // 5) moved too far -> it's a swipe; stayed still long enough -> it's a hold
        if (pressed && !holdFired) {
            val dx = (sx - startX) * svc.screenW()
            val dy = (sy - startY) * svc.screenH()
            if (!moved && hypot(dx, dy) > 36f * density) moved = true
            if (!moved && now - downT >= prefs.holdMs) {
                holdFired = true
                svc.longPress(startX, startY)
            }
        }

        hist.addLast(P(now, sx, sy))
        while (hist.isNotEmpty() && now - hist.first().t > 300) hist.removeFirst()

        val state = if (!pressed) 0 else if (holdFired) 2 else 1
        svc.moveCursor(sx, sy, state, prefs.cursorDp * density / 2f, prefs.showCursor, jump)
        jump = CursorView.JUMP_NONE
    }

    private fun release(svc: GestureService, now: Long) {
        pressed = false
        if (!holdFired) {
            if (moved) svc.swipe(startX, startY, sx, sy, (now - downT).coerceIn(120L, 500L))
            else svc.tap(startX, startY)
        }
        moved = false
        holdFired = false
    }

    private fun handLost(svc: GestureService) {
        lostFrames++
        if (lostFrames > 6 && pressed) {         // hand left the frame mid-touch: cancel, don't click
            pressed = false; moved = false; holdFired = false
        }
        if (lostFrames > 12 && haveFix) {
            haveFix = false
            hist.clear()
            baseline = 0f
            svc.hideCursor()
        }
    }
}
